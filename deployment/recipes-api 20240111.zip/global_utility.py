# Author:       Michael Rubin
# Created:      12/15/2022
# Modified:     1/6/2022
#
# Copyright 2023 - 2024 © Uptakeblue.com, All Rights Reserved
# -----------------------------------------------------------
import boto3
import json
import base64
import time

import pymysql
from pymysql import err

PYMYSQL_EXCEPTIONS = (
    err.DatabaseError,
    err.DataError,
    err.IntegrityError,
    err.InterfaceError,
    err.MySQLError,
    err.NotSupportedError,
    err.OperationalError,
    err.ProgrammingError,
)

isLocalDevelopment = False
useLocalSecret = False

localSecret = {}

RESPONSECODE_OK = 200
RESPONSECODE_CREATED = 201
RESPONSECODE_BADREQUEST = 400
RESPONSECODE_UNAUTHRORIZED = 401
RESPONSECODE_NOTFOUND = 404
RESPONSECODE_NOTALLOWED = 405
RESPONSECODE_SERVERERROR = 500

DATEFORMAT = "%Y-%m-%d"
DATETIMEFORMAT = "%Y-%m-%d %H:%M:%S"
NULLDATE = "0000-00-00"


class Global_Utility:
    # AWS SDK resources
    __boto3Session = None
    __s3Client = None
    __sesClient = None
    __lambdaClient = None
    __secretsClient = None
    __cognitoClient = None
    __dynamodbClient = None
    __dynamodbResource = None
    __snsResource = None
    __snsClient = None
    __firehoseClient = None
    __dynamodbTables = None
    __iotDataClient = None
    __athenaClient = None
    __pymysqlConnection = None

    def __init__(self, application):
        self.application = application
        self.settings = None
        self.StatusCode = None

        self.__pymysqlConnection = None

        try:
            if useLocalSecret:
                self.settings = localSecret
            else:
                secretName = f"{application}-secret"
                self.settings = self.getSecret(secretName)

            self.StatusCode = RESPONSECODE_OK

            self.__dynamodbTables = {}

        except Exception as e:
            msg = f"Error Retrieving Secret {secretName}"
            raise Exception(msg) from e

    def __del__(self):
        self.__closeDatabaseConnection()
        self.__pymysqlConnection = None

    ## PROPERTIES

    @property
    def boto3Session(self):
        if not self.__boto3Session:
            self.__boto3Session = boto3.session.Session()
        return self.__boto3Session

    @property
    def s3Client(self):
        if not self.__s3Client:
            self.__s3Client = self.boto3Session.client("s3")
        return self.__s3Client

    @property
    def sesClient(self):
        if not self.__sesClient:
            self.__sesClient = self.boto3Session.client("ses")
        return self.__sesClient

    @property
    def lambdaClient(self):
        if not self.__lambdaClient:
            self.__lambdaClient = self.boto3Session.client("lambda")
        return self.__lambdaClient

    @property
    def secretsClient(self):
        if not self.__secretsClient:
            self.__secretsClient = self.boto3Session.client("secretsmanager")
        return self.__secretsClient

    @property
    def cognitoClient(self):
        if not self.__cognitoClient:
            self.__cognitoClient = self.boto3Session.client("cognito-idp")
        return self.__cognitoClient

    @property
    def dynamodbResource(self):
        if not self.__dynamodbResource:
            self.__dynamodbResource = boto3.resource("dynamodb")
        return self.__dynamodbResource

    @property
    def dynamodbClient(self):
        if not self.__dynamodbClient:
            self.__dynamodbClient = boto3.client("dynamodb")
        return self.__dynamodbClient

    @property
    def snsResource(self):
        if not self.__snsResource:
            self.__snsResource = boto3.resource("sns")
        return self.__snsResource

    @property
    def snsClient(self):
        if not self.__snsClient:
            self.__snsClient = self.boto3Session.client("sns")
        return self.__snsClient

    @property
    def iotDataClient(self):
        if not self.__iotDataClient:
            self.__iotDataClient = self.boto3Session.client("iot-data")
        return self.__iotDataClient

    @property
    def firehoseClient(self):
        if not self.__firehoseClient:
            self.__firehoseClient = self.boto3Session.client("firehose")
        return self.__firehoseClient

    @property
    def athenaClient(self):
        if not self.__athenaClient:
            self.__athenaClient = self.boto3Session.client("athena")
        return self.__athenaClient

    @property
    def pymysqlConnection(self):
        if not self.__pymysqlConnection:
            mysqlEndpoint = self.settings["mysql_endpoint"]
            mysqlUsername = self.settings["mysql_username"]
            mysqlPassword = self.settings["mysql_password"]

            try:
                self.__pymysqlConnection = pymysql.connect(
                    host=mysqlEndpoint,
                    port=3306,
                    user=mysqlUsername,
                    password=mysqlPassword,
                )
                self.__pymysqlConnection
            except Exception as e:
                msg = f"Cannot open pyMySQL Connection for {mysqlEndpoint}"
                raise ConnectionError(msg) from e

        return self.__pymysqlConnection

    @pymysqlConnection.setter
    def pymysqlConnection(self, value):
        self.__pymysqlConnection = value

    def __closeDatabaseConnection(self):
        if self.__pymysqlConnection and self.__pymysqlConnection.open:
            self.__pymysqlConnection.commit()
            self.__pymysqlConnection.close()

    # methods
    def getDynamodbTable(self, tableName):
        table = None
        if tableName in self.__dynamodbTables:
            table = self.__dynamodbTables[tableName]
        else:
            table = self.dynamodbResource.Table(tableName)
            self.__dynamodbTables[tableName] = table

        return table

    def getSecret(self, secretName):
        if not secretName:
            return None
        try:
            secretValueResponse = self.secretsClient.get_secret_value(
                SecretId=secretName
            )

            if "SecretString" in secretValueResponse:
                secret = secretValueResponse["SecretString"]
            else:
                secret = base64.b64decode(secretValueResponse["SecretBinary"])
            secret = json.loads(secret)
            return secret
        except Exception as e:
            msg = f"Error Retrieving Secret {secretName}"
            raise Exception(msg) from e

    # event logging
    def writeEventDebug(self, title, message):
        self.printEvent("debug", title, message)

    def writeEventTiming(self, category, functionName, startTime):
        endTime = time.perf_counter() - startTime
        self.printEvent(
            "timing",
            f"{category.upper()}",
            f"{functionName} took {endTime:0.4f} seconds",
        )

    # format an information message
    def writeEvent(self, title, message):
        self.printEvent("information", title, message)

    # format an alert message
    def writeEventAlert(self, title, message):
        self.printEvent("alert", title, message)

    # format an exception message
    def writeEventError(self, title, e, *args):
        message = str(e)
        if e.args and len(e.args) > 1:
            message = f"Error Type: {type(e).__name__.replace('<class ', '').replace('>','')}, Message: {e.args[0]}, Trace: {e.args[1]}"

        if args:
            message = f"{message}. \nArgument(s): {str(args)}"
        self.printEvent("exception", title, message)

    # print to console and CloudWatch log
    def printEvent(self, eventType, title, message):
        global isLocalDevelopment
        prefix = "## LOG MESSAGE: "
        if eventType == "timing":
            prefix = "-- TIMING MESSAGE: "
        if eventType == "debug":
            prefix = "-- DEBUG MESSAGE: "
        elif eventType == "exception":
            # always print exception messages
            prefix = "## ERROR MESSAGE: "
        elif eventType == "alert":
            # always print alert messages
            prefix = "## LOG ALERT MESSAGE: "
        elif eventType == "information":
            # don"t print if eventLogSuppress is True
            prefix = "## LOG MESSAGE: "

        if message:
            if isinstance(message, dict):
                message = json.dumps(message, indent=4)
            elif isinstance(message, list):
                message = str(message)
        else:
            message = ""

        printTitle = title
        if message and not printTitle.endswith(":"):
            printTitle = f"{printTitle} - "

        if isLocalDevelopment:
            print(f"{prefix}{printTitle} {message}")
        else:
            if isinstance(message, str):
                message = message.replace("\n", "\r")
            if (
                eventType not in ["debug", "timing"]
                or "debug" not in self.settings
                or self.settings["debug"] == "true"
            ):
                print(f"{prefix}{printTitle} {' ' * 16}{message}")

    def __str__(self):
        return f"{self.__class__.__name__}({self.application})"


# generic custom exception
class UptakeblueException(Exception):
    ExceptionType = None
    StatusCode = RESPONSECODE_SERVERERROR
    Source = None
    __message: str = None
    __argsMessage = None
    __paramArgs: str = None

    def __init__(
        self,
        e,
        source,
        message=None,
        paramargs=None,
        statusCode=None,
    ):
        self.ExceptionType = type(e).__name__
        self.Source = source
        self.__message = message
        self.__paramArgs = paramargs

        if statusCode:
            self.StatusCode = statusCode

        elif type(e) in PYMYSQL_EXCEPTIONS:
            errNumber = int(e.args[0])
            self.StatusCode = errNumber - 10000
            if len(e.args) > 1:
                self.__argsMessage = str(e.args[1])

        if e.args and self.__argsMessage is None:
            self.__argsMessage = str(e.args[0])

    def SourceAppend(self, source: str):
        self.Source = f"{self.Source}, called from {source}" if self.Source else source

    @property
    def Message(self) -> str:
        predicate = (
            "An"
            if self.ExceptionType.upper()[0] in ["A", "E", "I", "O", "U", "Y"]
            else "A"
        )
        self.__message = (
            f"{predicate} {self.ExceptionType} exception" + f"occurred in {self.Source}"
            if self.Source
            else ""
        )

        if self.__argsMessage:
            self.__message = f"{self.__message}: {self.__argsMessage}"

        if self.__paramArgs:
            self.__message = f"{self.__message}.\nparamArgs:{', '.join(str(x) for x in self.__paramArgs)}"

        return self.__message


## EXCEPTION HANDLER


def exceptionResponse(e: Exception):
    err = None
    try:
        if isinstance(e, UptakeblueException):
            err: UptakeblueException = e
        else:
            err = UptakeblueException(e)

    except Exception as e:
        raise (str(e, 400))

    return (err.Message, err.StatusCode)
